#include <iostream>
using namespace std;

int main() {
    int n, m, k;
    cin >> n >> m >> k;
    cout << (n / m + 1) * k << "\n";
}
